(function () {

    'use strict';

    const cars =document.querySelector('#cars');
    // document.querySelector('#cars').addEventListener('scroll', function (){
    //     document.getElementById('overlay').className='showing';
    // });

    cars.addEventListener('wheel', function (event){
        event.preventDefault();
        cars.scrollBy({
            left: event.deltaY
        });
    });

})();